@include('__partials.header')
<main class="main">
    <section>
        <div class="content_title_section">
            {{-- <div>
                <h1>filtrar productos por / todos </h1>
            </div>
            <div class="content_play_section flex">
                <img src="{{ asset('icon/go.png') }}" alt="">
                <h4>click aqui<br> para filtrar<br> por tags</h4>
            </div> --}}
            <img src="{{ asset('img/filtrar.png') }}" alt="" width="100%">
        </div>
    </section>

    <section>
        <div class="content_products flex">
            {{-- <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 18 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
                <div><img src="{{ asset('img/Rectangle 11 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
            </div>
            <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 11.png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
                <div><img src="{{ asset('img/Rectangle 11 (2).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
            </div>
            <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 12 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>

            </div> --}}
            <img src="{{ asset('img/bloque 01.png') }}" alt="" width="100%">
        </div>
    </section>
    <section>
        <div class="product_title">
            <p>filtrar productos por / todos </p>
        </div>
    </section>
    <section>
        <div class="content_products flex">
            {{-- <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 12 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
            </div>
            <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 18 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
                <div><img src="{{ asset('img/Rectangle 11 (1).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
            </div>
            <div class="one_producst">
                <div><img src="{{ asset('img/Rectangle 11.png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
                <div><img src="{{ asset('img/Rectangle 11 (2).png') }}" alt="">
                    <div class="price flex between">
                        <p class="name_product">emanate
                            cheek / skin tint</p>
                        <p class="price_product">$ 25.000</p>
                    </div>
                </div>
            </div> --}}
            <img src="{{ asset('img/bloque 02.png') }}" alt="" width="100%">
        </div>
    </section>

</main>

@include('__partials.footer')
