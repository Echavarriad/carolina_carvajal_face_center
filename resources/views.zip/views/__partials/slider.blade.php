<section>
    <div class="slider_content_two left">
        <img src="{{ asset('img/slider (1).png') }}" alt="" width="100%">
    </div>
    {{-- <div class="img_over_banner">
        <img src="{{ asset('img/mujer 2.png') }}" alt="">

    </div> --}}
    {{-- <div class="text_banner_right">
        <h1>Find the perfect
            shade for
            you once...</h1>
    </div>
    <div class="text_banner_left">
        <p>ba
            ck</p>
        <hr>
        <p>
            ne
            xt
        </p>
    </div> --}}
</section>
