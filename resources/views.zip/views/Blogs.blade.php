@include('__partials.header')
<main class="main">
    <section class="section_four_main">
        <div class="flex center">
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 17.png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 17 (1).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/01(7).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
        </div>
    </section>
    <section class="section_four_main">
        <div class="flex center">
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (1).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (2).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (6).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
        </div>
    </section>
    <section class="section_four_main">
        <div class="flex center">
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (5).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (3).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
            <div class="section_four_content">
                <div><img class="img" src="{{ asset('img/Rectangle 16 (4).png') }}" alt=""></div>
                <div>
                    <p>New survey sheds light on providers'
                        embrace of telemedicine</p>
                    <a href="{{ route('blog_expansion') }}">... Leer este blog</a>
                </div>
            </div>
        </div>
    </section>
</main>

@include('__partials.footer')
