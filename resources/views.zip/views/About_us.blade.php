@include('__partials.header')
<main class="main">
    <section class="section_one_main">
        {{-- <section class="section_one_about">
            <div class="content_one flex">
                <div class="section_one_main--left">
                    <p class="section_title">On the other hand, we magna<br> with right

                        shrinking
                        cases<br>
                        are perfectly simple.</p>
                    <h4>being able to do what we<br>
                        like best, every</h4>
                    <p>be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty
                        or the obligations of business it will frequently occur that pleasures have to be repudiated and
                        annoyances accepted.

                        The wise man therefore always holds in these matters to this principle of selection: he rejects
                        pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.</p>
                </div>
                <div class="section_one_main--right"><img src="{{ asset('img/01 (1).png') }}" alt=""></div>
            </div>
            <div class="content_one flex">
                <div class="section_two_main--left"><img src="{{ asset('img/Rectangle 16.png') }}" alt=""></div>
                <div class="section_two_main--right">
                    <p class="section_subtitle">the claims of duty or the<br> obligations of business</p>

                    <p>belongs to those who fail in their duty through weakness of will, which is the same as saying
                        through shrinking from toil and pain. These cases are perfectly simple and easy to
                        distinguish.<br><br>

                        In a free hour, when our power of choice is untrammelled and when nothing prevents our being
                        able to do what we like best,</p>
                </div>

            </div>
        </section>
        <section class="section_two_main">
            <div class="content_two flex">
                <div class="section_about">
                    <h3>Who We Are</h3><br>
                    <p>saying indignation and dislike men who are so<br> beguiled and demoralized by the charms of<br>
                        pleasure
                        of
                        the moment, so blinded by desire, <br>that they cannot foresee the pain and trouble<br> that are
                        bound.
                        <br>

                        blame belongs to those who fail in their duty<br> through weakness of will, which is the same
                        as<br>
                        saying
                        through shrinking from toil and bain.
                    </p>
                </div>
                <div class="section_about">
                    <h3>What We Do</h3>
                    <br>
                    <p>welcome indignation and dislike men who are<br> so beguiled and demoralized by the charms of<br>
                        pleasure
                        of the moment, so blinded by desire,<br> that they cannot foresee the pain and trouble<br> that
                        are
                        bound.<br>

                        blame belongs to those who fail in their duty<br> through weakness of will, which is the same
                        as<br>
                        saying through shrinking from toil and bain.</p>
                </div>
                <div class="section_about">
                    <h3>vision / mission / values</h3>
                    <br>
                    <p>principle indignation and dislike men who are<br> so beguiled and demoralized by the charms
                        of<br>
                        pleasure of the moment, so blinded by desire,<br> that they cannot foresee the pain and
                        trouble<br>
                        that
                        are bound.<br>

                        blame belongs to those who fail in their duty<br> through weakness of will, which is the same
                        as<br>
                        saying through shrinking from toil and bain.</p>
                </div>
            </div>
        </section> --}}
        <img src="{{ asset('img/info 01.png') }}" alt="" width="100%" style="margin-top: 5%;margin-bottom: 5%">
        <div class="about_us flex">
            <img src="{{ asset('img/info 02.png') }}" alt="" style="margin-bottom: 7%" width="80%">
        </div>

    </section>
    <section class="banner" style="margin: 0">
        <div class="backgroun-img">
            <img src="{{ asset('img/video 2.png') }}" alt="" width="100%">

        </div>
    </section>
</main>

@include('__partials.footer')
